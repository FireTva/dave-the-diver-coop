using BepInEx;
using BepInEx.Unity.IL2CPP;
using UnityEngine;

namespace DaveTheDiverCoop;

[BepInPlugin("coop-anything.davethediver", "DAVE THE DIVER Co-op", "0.1.0")]
public sealed class Plugin : BasePlugin
{
    public override void Load()
    {
        AddComponent<CoopBehaviour>();
        Log.LogInfo("DAVE THE DIVER Co-op prototype loaded.");
    }
}
