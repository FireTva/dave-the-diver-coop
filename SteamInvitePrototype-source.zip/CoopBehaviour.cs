using System.Buffers.Binary;
using System.Globalization;
using System.Runtime.InteropServices;
using Il2CppInterop.Runtime;
using BepInEx.Unity.IL2CPP;
using Steamworks;
using UnityEngine;

namespace DaveTheDiverCoop;

public sealed class CoopBehaviour : MonoBehaviour
{
    private const string ProtocolVersion = "1";
    private const string BuildId = "25315876";
    private const int PosePacketLength = 18;
    private const float PoseSendInterval = 1f / 15f;
    private const float PoseTimeout = 3f;
    private const float MaxCoordinateMagnitude = 10000f;
    private const int MaxMessagesPerFrame = 8;
    private const int LobbyMemberLimit = 2;

    private readonly IntPtr[] _receivedMessages = new IntPtr[MaxMessagesPerFrame];
    private readonly byte[] _packetBuffer = new byte[PosePacketLength];
    private readonly byte[] _receiveBuffer = new byte[PosePacketLength];
    private string _status = "Enter the same Blue Hole dive to host or join.";
    private string _joinLobbyId = string.Empty;
    private CSteamID _pendingInvite = CSteamID.Nil;
    private Callback<LobbyEnter_t>? _lobbyEnteredCallback;
    private Callback<GameLobbyJoinRequested_t>? _lobbyJoinRequestedCallback;
    private CallResult<LobbyCreated_t>? _lobbyCreatedResult;
    private CSteamID _lobby = CSteamID.Nil;
    private CSteamID _remoteUser = CSteamID.Nil;
    private GameObject? _remotePlayer;
    private SpriteRenderer? _remoteRenderer;
    private Vector3 _remoteTarget;
    private float _lastPoseReceived;
    private float _poseSendTimer;
    private uint _sentSequence;
    private uint _receivedSequence;
    private bool _hasRemotePose;
    private bool _hasReceivedSequence;
    private bool _remoteFlipX;
    private bool _isHost;
    private bool _callbacksRegistered;
    private bool _creatingLobby;

    public CoopBehaviour(IntPtr pointer) : base(pointer)
    {
    }

    private void Update()
    {
        if (SteamManager.Initialized)
        {
            RegisterCallbacks();
        }

        PlayerCharacter? localPlayer = GetLocalPlayer();
        bool inDive = localPlayer != null && localPlayer.bodyRenderer != null;

        if (!inDive && (_lobby.m_SteamID != 0 || _creatingLobby || _remoteUser.m_SteamID != 0))
        {
            LeaveDive("Co-op ended because you left the Blue Hole dive.");
        }

        if (_pendingInvite.m_SteamID != 0 && inDive && _lobby.m_SteamID == 0 && !_creatingLobby)
        {
            JoinLobby(_pendingInvite);
        }

        if (_lobby.m_SteamID != 0 && inDive)
        {
            RefreshLobbyPeer();
            if (_remoteUser.m_SteamID != 0)
            {
                ReceivePoses();
                SendPose(localPlayer!);
            }
        }

        UpdateRemotePlayer(localPlayer, inDive);
    }

    private void OnGUI()
    {
        PlayerCharacter? localPlayer = GetLocalPlayer();
        if (localPlayer == null || localPlayer.bodyRenderer == null)
        {
            return;
        }

        GUILayout.BeginArea(new Rect(12f, 12f, 360f, 172f), string.Empty, GUI.skin.box);
        GUILayout.Label("DAVE THE DIVER Co-op (prototype)", Array.Empty<GUILayoutOption>());
        GUILayout.Label(_status, Array.Empty<GUILayoutOption>());

        if (!SteamManager.Initialized)
        {
            GUILayout.Label("Steam is not initialized for this game session.", Array.Empty<GUILayoutOption>());
        }
        else if (_lobby.m_SteamID == 0)
        {
            GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
            if (GUILayout.Button("Host friends-only dive", Array.Empty<GUILayoutOption>()))
            {
                HostDive();
            }
            GUILayout.EndHorizontal();

            GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
            _joinLobbyId = GUILayout.TextArea(
                _joinLobbyId,
                new[] { GUILayout.Width(230f), GUILayout.Height(25f) });
            if (GUILayout.Button("Join by lobby ID", Array.Empty<GUILayoutOption>()))
            {
                JoinDive();
            }
            GUILayout.EndHorizontal();
        }
        else
        {
            GUILayout.Label(
                $"Lobby ID: {_lobby.m_SteamID.ToString(CultureInfo.InvariantCulture)}",
                Array.Empty<GUILayoutOption>());
            GUILayout.BeginHorizontal(Array.Empty<GUILayoutOption>());
            if (_isHost && GUILayout.Button("Invite Steam friend", Array.Empty<GUILayoutOption>()))
            {
                SteamFriends.ActivateGameOverlayInviteDialog(_lobby);
            }
            if (GUILayout.Button("Leave dive", Array.Empty<GUILayoutOption>()))
            {
                LeaveDive("Left the co-op dive.");
            }
            GUILayout.EndHorizontal();
        }

        GUILayout.EndArea();
    }

    private void OnDestroy()
    {
        LeaveDive("Co-op session closed.");
        if (_remotePlayer != null)
        {
            Destroy(_remotePlayer);
            _remotePlayer = null;
            _remoteRenderer = null;
        }
        _lobbyEnteredCallback?.Dispose();
        _lobbyJoinRequestedCallback?.Dispose();
        _lobbyCreatedResult?.Dispose();
    }

    private static PlayerCharacter? GetLocalPlayer()
    {
        if (SceneContext.SceneTypeRP == null || SceneContext.SceneTypeRP.Value != SceneType.level)
        {
            return null;
        }

        return InGameManager.TryGetPlayerCharacter;
    }

    private void RegisterCallbacks()
    {
        if (_callbacksRegistered)
        {
            return;
        }

        _lobbyEnteredCallback = Callback<LobbyEnter_t>.Create(
            DelegateSupport.ConvertDelegate<Callback<LobbyEnter_t>.DispatchDelegate>(
                new Action<LobbyEnter_t>(OnLobbyEntered))!);
        _lobbyJoinRequestedCallback = Callback<GameLobbyJoinRequested_t>.Create(
            DelegateSupport.ConvertDelegate<Callback<GameLobbyJoinRequested_t>.DispatchDelegate>(
                new Action<GameLobbyJoinRequested_t>(OnLobbyJoinRequested))!);
        _callbacksRegistered = true;
    }

    private void HostDive()
    {
        if (!CanStartSession())
        {
            return;
        }

        _creatingLobby = true;
        _isHost = true;
        _lobbyCreatedResult = CallResult<LobbyCreated_t>.Create(
            DelegateSupport.ConvertDelegate<CallResult<LobbyCreated_t>.APIDispatchDelegate>(
                new Action<LobbyCreated_t, bool>(OnLobbyCreated))!);
        _lobbyCreatedResult.Set(
            SteamMatchmaking.CreateLobby(ELobbyType.k_ELobbyTypeFriendsOnly, LobbyMemberLimit));
        _status = "Creating a friends-only lobby...";
    }

    private void JoinDive()
    {
        if (!CanStartSession())
        {
            return;
        }

        if (!ulong.TryParse(_joinLobbyId, NumberStyles.None, CultureInfo.InvariantCulture, out ulong lobbyId)
            || lobbyId == 0)
        {
            _status = "Enter a valid Steam lobby ID.";
            return;
        }

        JoinLobby(new CSteamID(lobbyId));
    }

    private bool CanStartSession()
    {
        if (!SteamManager.Initialized)
        {
            _status = "Steam is not initialized for this game session.";
            return false;
        }

        if (GetLocalPlayer() == null)
        {
            _status = "Enter a Blue Hole dive before starting a co-op session.";
            return false;
        }

        if (_lobby.m_SteamID != 0)
        {
            _status = "Leave the current lobby before starting another.";
            return false;
        }

        if (_creatingLobby)
        {
            _status = "Wait for the lobby creation request to finish.";
            return false;
        }

        RegisterCallbacks();
        return true;
    }

    private void OnLobbyCreated(LobbyCreated_t result, bool ioFailure)
    {
        _lobbyCreatedResult?.Dispose();
        _lobbyCreatedResult = null;
        _creatingLobby = false;

        if (ioFailure || result.m_eResult != EResult.k_EResultOK)
        {
            _isHost = false;
            _status = "Steam could not create the lobby.";
            return;
        }

        _lobby = new CSteamID(result.m_ulSteamIDLobby);
        if (!SteamMatchmaking.SetLobbyMemberLimit(_lobby, LobbyMemberLimit))
        {
            LeaveDive("Steam could not set the two-player lobby limit.");
            return;
        }

        string sceneName = SceneContext.hasInstance ? SceneContext.Instance.CurrentSceneName : string.Empty;
        if (string.IsNullOrEmpty(sceneName))
        {
            LeaveDive("The current Blue Hole scene is not ready for co-op.");
            return;
        }

        bool metadataSet =
            SteamMatchmaking.SetLobbyData(_lobby, "coop.protocol", ProtocolVersion)
            && SteamMatchmaking.SetLobbyData(_lobby, "coop.build", BuildId)
            && SteamMatchmaking.SetLobbyData(_lobby, "coop.scene", sceneName);

        if (!metadataSet)
        {
            LeaveDive("Steam could not publish lobby compatibility data.");
            return;
        }

        _status = "Lobby ready. Invite one Steam friend to join.";
    }

    private void OnLobbyJoinRequested(GameLobbyJoinRequested_t request)
    {
        if (_lobby.m_SteamID != 0 || _creatingLobby)
        {
            _status = "Leave the current lobby before joining a Steam invite.";
            return;
        }

        _pendingInvite = request.m_steamIDLobby;
        if (GetLocalPlayer() == null)
        {
            _status = "Steam invite received. Enter the same Blue Hole scene to join.";
            return;
        }

        JoinLobby(_pendingInvite);
    }

    private void JoinLobby(CSteamID lobby)
    {
        _pendingInvite = CSteamID.Nil;
        _lobby = lobby;
        SteamMatchmaking.JoinLobby(_lobby);
        _status = "Joining the Steam lobby...";
    }

    private void OnLobbyEntered(LobbyEnter_t result)
    {
        var enteredLobby = new CSteamID(result.m_ulSteamIDLobby);
        if (_lobby.m_SteamID != 0 && enteredLobby.m_SteamID != _lobby.m_SteamID)
        {
            return;
        }

        _lobby = enteredLobby;
        if (result.m_EChatRoomEnterResponse != 1)
        {
            LeaveDive("Steam denied entry to that lobby.");
            return;
        }

        CSteamID owner = SteamMatchmaking.GetLobbyOwner(_lobby);
        if (owner == SteamUser.GetSteamID())
        {
            if (!_creatingLobby)
            {
                _status = "Lobby ready. Invite one Steam friend to join.";
            }
            return;
        }

        if (SteamMatchmaking.GetLobbyData(_lobby, "coop.protocol") != ProtocolVersion
            || SteamMatchmaking.GetLobbyData(_lobby, "coop.build") != BuildId)
        {
            LeaveDive("This lobby uses a different mod protocol or game build.");
            return;
        }

        string localScene = SceneContext.hasInstance ? SceneContext.Instance.CurrentSceneName : string.Empty;
        if (string.IsNullOrEmpty(localScene)
            || SteamMatchmaking.GetLobbyData(_lobby, "coop.scene") != localScene)
        {
            LeaveDive("Both players must be in the same Blue Hole scene.");
            return;
        }

        _remoteUser = owner;
        _status = "Joined the lobby. Waiting for the host's diver position...";
    }

    private void RefreshLobbyPeer()
    {
        if (_remoteUser.m_SteamID != 0 && !IsLobbyMember(_remoteUser))
        {
            ClosePeerSession(_remoteUser);
            _remoteUser = CSteamID.Nil;
            _hasRemotePose = false;
            _hasReceivedSequence = false;
            if (!_isHost)
            {
                LeaveDive("The dive host left the co-op lobby.");
                return;
            }

            _status = "Your partner left. Waiting for another Steam friend...";
        }

        if (_remoteUser.m_SteamID != 0)
        {
            return;
        }

        int memberCount = SteamMatchmaking.GetNumLobbyMembers(_lobby);
        for (int i = 0; i < memberCount; i++)
        {
            CSteamID member = SteamMatchmaking.GetLobbyMemberByIndex(_lobby, i);
            if (member != SteamUser.GetSteamID())
            {
                _remoteUser = member;
                _status = "Partner found. Syncing diver positions...";
                return;
            }
        }
    }

    private bool IsLobbyMember(CSteamID user)
    {
        int memberCount = SteamMatchmaking.GetNumLobbyMembers(_lobby);
        for (int i = 0; i < memberCount; i++)
        {
            if (SteamMatchmaking.GetLobbyMemberByIndex(_lobby, i) == user)
            {
                return true;
            }
        }

        return false;
    }

    private void SendPose(PlayerCharacter localPlayer)
    {
        if (_remoteUser.m_SteamID == 0)
        {
            return;
        }

        _poseSendTimer += Time.unscaledDeltaTime;
        if (_poseSendTimer < PoseSendInterval)
        {
            return;
        }
        _poseSendTimer %= PoseSendInterval;

        SpriteRenderer body = localPlayer.bodyRenderer;
        Vector3 position = body.transform.position;
        _packetBuffer[0] = 1;
        BinaryPrimitives.WriteUInt32LittleEndian(_packetBuffer.AsSpan(1, sizeof(uint)), ++_sentSequence);
        BinaryPrimitives.WriteSingleLittleEndian(_packetBuffer.AsSpan(5, sizeof(float)), position.x);
        BinaryPrimitives.WriteSingleLittleEndian(_packetBuffer.AsSpan(9, sizeof(float)), position.y);
        BinaryPrimitives.WriteSingleLittleEndian(_packetBuffer.AsSpan(13, sizeof(float)), position.z);
        _packetBuffer[17] = body.flipX ? (byte)1 : (byte)0;

        IntPtr data = Marshal.AllocHGlobal(PosePacketLength);
        try
        {
            Marshal.Copy(_packetBuffer, 0, data, PosePacketLength);
            var remoteIdentity = new SteamNetworkingIdentity();
            remoteIdentity.SetSteamID(_remoteUser);
            EResult sendResult = SteamNetworkingMessages.SendMessageToUser(
                ref remoteIdentity,
                data,
                (uint)PosePacketLength,
                Constants.k_nSteamNetworkingSend_UnreliableNoDelay
                    | Constants.k_nSteamNetworkingSend_AutoRestartBrokenSession,
                0);
            if (sendResult != EResult.k_EResultOK)
            {
                _status = $"SteamNetworkingMessages send failed: {sendResult}.";
            }
        }
        finally
        {
            Marshal.FreeHGlobal(data);
        }
    }

    private void ReceivePoses()
    {
        int messageCount = SteamNetworkingMessages.ReceiveMessagesOnChannel(
            0,
            _receivedMessages,
            MaxMessagesPerFrame);

        for (int i = 0; i < messageCount; i++)
        {
            IntPtr messagePointer = _receivedMessages[i];
            if (messagePointer == IntPtr.Zero)
            {
                continue;
            }

            try
            {
                SteamNetworkingMessage_t message = SteamNetworkingMessage_t.FromIntPtr(messagePointer);
                if (message.m_cbSize != PosePacketLength
                    || message.m_pData == IntPtr.Zero
                    || message.m_identityPeer.GetSteamID() != _remoteUser)
                {
                    continue;
                }

                Marshal.Copy(message.m_pData, _receiveBuffer, 0, PosePacketLength);
                if (_receiveBuffer[0] != 1)
                {
                    continue;
                }

                uint sequence = BinaryPrimitives.ReadUInt32LittleEndian(_receiveBuffer.AsSpan(1, sizeof(uint)));
                if (_hasReceivedSequence && !IsSequenceNewer(sequence, _receivedSequence))
                {
                    continue;
                }

                float x = BinaryPrimitives.ReadSingleLittleEndian(_receiveBuffer.AsSpan(5, sizeof(float)));
                float y = BinaryPrimitives.ReadSingleLittleEndian(_receiveBuffer.AsSpan(9, sizeof(float)));
                float z = BinaryPrimitives.ReadSingleLittleEndian(_receiveBuffer.AsSpan(13, sizeof(float)));
                if (!float.IsFinite(x)
                    || !float.IsFinite(y)
                    || !float.IsFinite(z)
                    || MathF.Abs(x) > MaxCoordinateMagnitude
                    || MathF.Abs(y) > MaxCoordinateMagnitude
                    || MathF.Abs(z) > MaxCoordinateMagnitude
                    || _receiveBuffer[17] > 1)
                {
                    continue;
                }

                _receivedSequence = sequence;
                _hasReceivedSequence = true;
                _remoteTarget = new Vector3(x, y, z);
                _remoteFlipX = _receiveBuffer[17] == 1;
                _lastPoseReceived = Time.unscaledTime;
                _hasRemotePose = true;
            }
            finally
            {
                SteamNetworkingMessage_t.Release(messagePointer);
                _receivedMessages[i] = IntPtr.Zero;
            }
        }
    }

    private static bool IsSequenceNewer(uint sequence, uint previous)
    {
        return sequence != previous && unchecked((int)(sequence - previous)) > 0;
    }

    private void UpdateRemotePlayer(PlayerCharacter? localPlayer, bool inDive)
    {
        bool poseIsFresh = _hasRemotePose && Time.unscaledTime - _lastPoseReceived <= PoseTimeout;
        if (!inDive || localPlayer == null || !poseIsFresh)
        {
            if (_remotePlayer != null)
            {
                _remotePlayer.SetActive(false);
            }
            return;
        }

        SpriteRenderer localBody = localPlayer.bodyRenderer;
        if (localBody == null || localBody.sprite == null)
        {
            return;
        }

        if (_remotePlayer == null)
        {
            _remotePlayer = new GameObject("Co-op remote diver");
            _remotePlayer.transform.position = _remoteTarget;
            _remoteRenderer = _remotePlayer.AddComponent<SpriteRenderer>();
        }

        _remotePlayer.SetActive(true);
        _remotePlayer.transform.position = Vector3.Lerp(
            _remotePlayer.transform.position,
            _remoteTarget,
            Mathf.Clamp01(Time.unscaledDeltaTime * 14f));
        _remotePlayer.transform.rotation = localBody.transform.rotation;
        _remotePlayer.transform.localScale = localBody.transform.lossyScale;

        _remoteRenderer!.sprite = localBody.sprite;
        _remoteRenderer.flipX = _remoteFlipX;
        _remoteRenderer.sortingLayerID = localBody.sortingLayerID;
        _remoteRenderer.sortingOrder = localBody.sortingOrder + 1;
        _remoteRenderer.color = new Color(0.35f, 0.85f, 1f, 0.88f);
    }

    private void LeaveDive(string status)
    {
        if (SteamManager.Initialized && _remoteUser.m_SteamID != 0)
        {
            ClosePeerSession(_remoteUser);
        }

        if (_lobby.m_SteamID != 0 && SteamManager.Initialized)
        {
            SteamMatchmaking.LeaveLobby(_lobby);
        }

        _lobby = CSteamID.Nil;
        _remoteUser = CSteamID.Nil;
        _pendingInvite = CSteamID.Nil;
        _isHost = false;
        _creatingLobby = false;
        _hasRemotePose = false;
        _receivedSequence = 0;
        _hasReceivedSequence = false;
        if (_remotePlayer != null)
        {
            _remotePlayer.SetActive(false);
        }

        _status = status;
    }

    private void ClosePeerSession(CSteamID user)
    {
        var remoteIdentity = new SteamNetworkingIdentity();
        remoteIdentity.SetSteamID(user);
        SteamNetworkingMessages.CloseSessionWithUser(ref remoteIdentity);
    }
}
